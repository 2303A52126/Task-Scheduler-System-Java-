#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────
#  run.sh — One-command build & run for Task Scheduler System
# ─────────────────────────────────────────────────────────────────
set -e

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/out"

echo "🔨  Compiling..."
mkdir -p "$OUT"
javac -d "$OUT" "$ROOT"/src/main/java/scheduler/*.java

echo "✅  Build successful."
echo ""
echo "🚀  Launching Task Scheduler..."
echo ""
java -cp "$OUT" scheduler.Main
