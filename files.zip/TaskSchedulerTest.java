package scheduler;

import java.time.LocalDateTime;

/**
 * TaskSchedulerTest — Lightweight unit tests (no JUnit dependency).
 * Run: java -cp out scheduler.TaskSchedulerTest
 *
 * For a real project, replace this with JUnit 5 / Mockito tests.
 */
public class TaskSchedulerTest {

    private static int passed = 0;
    private static int failed = 0;

    public static void main(String[] args) {
        System.out.println("=== Task Scheduler Unit Tests ===\n");

        testAddTask();
        testDuplicateTask();
        testPriorityOrder();
        testDeleteTask();
        testEmptyExecute();
        testDependencySatisfied();
        testCycleDetection();
        testExecutionLog();

        System.out.println("\n=== Results: " + passed + " passed, " + failed + " failed ===");
        if (failed > 0) System.exit(1);
    }

    // ── Test Cases ────────────────────────────────────────────────────────────

    static void testAddTask() {
        TaskScheduler ts = new TaskScheduler();
        Task t = new Task("Alpha", Task.Priority.HIGH);
        boolean result = ts.addTask(t);
        assertTrue("addTask returns true", result);
        assertEquals("size is 1 after add", 1, ts.size());
    }

    static void testDuplicateTask() {
        TaskScheduler ts = new TaskScheduler();
        ts.addTask(new Task("Beta", Task.Priority.LOW));
        boolean result = ts.addTask(new Task("Beta", Task.Priority.HIGH));
        assertFalse("duplicate task rejected", result);
        assertEquals("size stays 1", 1, ts.size());
    }

    static void testPriorityOrder() {
        TaskScheduler ts = new TaskScheduler();
        ts.addTask(new Task("LowTask",    Task.Priority.LOW));
        ts.addTask(new Task("HighTask",   Task.Priority.HIGH));
        ts.addTask(new Task("MedTask",    Task.Priority.MEDIUM));

        java.util.Optional<Task> first = ts.executeNext();
        assertTrue("first executed task present", first.isPresent());
        assertEquals("HIGH task executes first",
                "HighTask", first.get().getName());

        java.util.Optional<Task> second = ts.executeNext();
        assertEquals("MEDIUM task executes second",
                "MedTask", second.get().getName());
    }

    static void testDeleteTask() {
        TaskScheduler ts = new TaskScheduler();
        Task t = new Task("Gamma", Task.Priority.MEDIUM);
        ts.addTask(t);
        boolean deleted = ts.deleteTask(t.getId());
        assertTrue("deleteTask returns true", deleted);
        assertEquals("size is 0 after delete", 0, ts.size());
    }

    static void testEmptyExecute() {
        TaskScheduler ts = new TaskScheduler();
        java.util.Optional<Task> result = ts.executeNext();
        assertFalse("executeNext on empty returns empty", result.isPresent());
    }

    static void testDependencySatisfied() {
        TaskScheduler ts = new TaskScheduler();
        Task a = new Task("TaskA", Task.Priority.LOW);
        Task b = new Task("TaskB", Task.Priority.HIGH);
        ts.addTask(a);
        ts.addTask(b);
        // B depends on A — even though B is HIGH priority, A must run first
        ts.addDependency(b.getId(), a.getId());

        java.util.Optional<Task> first = ts.executeNext();
        assertTrue("first executed present", first.isPresent());
        assertEquals("A executes first (B is blocked)", "TaskA", first.get().getName());

        java.util.Optional<Task> second = ts.executeNext();
        assertEquals("B executes after A", "TaskB", second.get().getName());
    }

    static void testCycleDetection() {
        TaskScheduler ts = new TaskScheduler();
        Task a = new Task("CycleA", Task.Priority.HIGH);
        Task b = new Task("CycleB", Task.Priority.MEDIUM);
        ts.addTask(a);
        ts.addTask(b);
        ts.addDependency(a.getId(), b.getId()); // A depends on B
        boolean cycle = ts.addDependency(b.getId(), a.getId()); // B depends on A — cycle!
        assertFalse("cycle dependency rejected", cycle);
    }

    static void testExecutionLog() {
        TaskScheduler ts = new TaskScheduler();
        ts.addTask(new Task("LogTask", Task.Priority.HIGH));
        ts.executeNext();
        // Execution log is printed to stdout; verify no exception thrown
        ts.viewExecutionLog();
        pass("execution log displayed without error");
    }

    // ── Assertion Helpers ─────────────────────────────────────────────────────

    static void assertTrue(String msg, boolean condition) {
        if (condition) { pass(msg); } else { fail(msg + " — expected true"); }
    }

    static void assertFalse(String msg, boolean condition) {
        if (!condition) { pass(msg); } else { fail(msg + " — expected false"); }
    }

    static void assertEquals(String msg, Object expected, Object actual) {
        if (expected.equals(actual)) {
            pass(msg);
        } else {
            fail(msg + " — expected: " + expected + ", got: " + actual);
        }
    }

    static void pass(String msg) {
        System.out.println("  [PASS] " + msg);
        passed++;
    }

    static void fail(String msg) {
        System.out.println("  [FAIL] " + msg);
        failed++;
    }
}
