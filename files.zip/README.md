# 📋 Task Scheduler System

> A priority-queue–driven task scheduling engine in Java, demonstrating core Data Structures concepts relevant to Amazon SDE internship interviews.

---

## 🚀 Features

| Feature | Description |
|---|---|
| **Add Task** | Name, Priority (HIGH / MEDIUM / LOW), optional scheduled time |
| **Priority Queue** | Min-heap ensures highest-priority task always executes first |
| **Dependency Graph** | Kahn's BFS topological sort — tasks wait for prerequisites |
| **Execute Next** | Polls heap, skips dependency-blocked tasks |
| **Execute All** | Drains queue in correct priority + dependency order |
| **Delete Task** | Remove by ID without executing |
| **Execution Log** | Timestamped history of all completed tasks |
| **Cycle Detection** | BFS prevents dependency deadlocks at insertion time |
| **Menu UI** | Fully interactive console interface with ANSI colours |

---

## 🛠 Tech Stack

- **Language:** Java 17+
- **Core DSA:** `PriorityQueue<Task>` (Binary Heap), `HashMap`, Adjacency List
- **Algorithms:** Kahn's BFS Topological Sort, DFS Cycle Detection
- **OOP:** Encapsulation, Comparable, Enums, Single Responsibility

---

## 📁 Project Structure

```
task-scheduler-system/
├── src/
│   ├── main/java/scheduler/
│   │   ├── Task.java            # Domain model (Comparable, Priority enum)
│   │   ├── TaskScheduler.java   # Core engine (PQ + dependency graph)
│   │   └── Main.java            # Console menu + demo seed data
│   └── test/java/scheduler/
│       └── TaskSchedulerTest.java  # Lightweight unit tests
├── scripts/
│   └── run.sh                   # One-command build & run
├── .gitignore
└── README.md
```

---

## ⚙️ How to Run

### Prerequisites
- Java 17+ installed (`java --version`)

### Option A — Using the shell script
```bash
chmod +x scripts/run.sh
./scripts/run.sh
```

### Option B — Manual compile & run
```bash
# 1. Compile
mkdir -p out
javac -d out src/main/java/scheduler/*.java

# 2. Run the app
java -cp out scheduler.Main

# 3. Run tests
javac -d out src/test/java/scheduler/TaskSchedulerTest.java -cp out
java -cp out scheduler.TaskSchedulerTest
```

---

## 🖥 Example Session

```
  ╔══════════════════════════════════════════════╗
  ║        TASK SCHEDULER SYSTEM  v1.0           ║
  ║   Priority Queue · Graph Dependencies · OOP  ║
  ╚══════════════════════════════════════════════╝

  Loading demo tasks...
  [OK] Task added: [3F8A1B2C] Deploy Production Release (HIGH)
  [OK] Task added: [7D2E9F4A] Fix Critical Security Bug (HIGH)
  ...6 demo tasks loaded.

  ┌─────────────────────────────────┐
  │           MAIN MENU             │
  ├─────────────────────────────────┤
  │  1. Add Task                    │
  │  2. View All Tasks              │
  │  3. Execute Next Task           │
  │  ...                            │
  └─────────────────────────────────┘

  Enter choice: 3

  ── Execute Next Task ──
  ✔  Executed: [7D2E9F4A] Fix Critical Security Bug (HIGH)
     Priority : HIGH
     Remaining: 5 task(s) in queue
```

---

## ⏱ Time Complexity

| Operation | Data Structure | Complexity |
|---|---|---|
| `addTask()` | Binary Heap insert | **O(log n)** |
| `executeNext()` | Heap poll | **O(log n)** |
| `deleteTask()` | Heap remove + resift | **O(n)** |
| `viewAll()` | Sort copy | **O(n log n)** |
| `taskMap` lookup | HashMap | **O(1) avg** |
| `addDependency()` | BFS cycle check | **O(V + E)** |
| `displayOrder()` | Kahn's BFS topo sort | **O(V + E)** |
| `executeAll()` | Repeated heap poll | **O(n log n)** |

**Space Complexity:** O(V + E) — heap + HashMap + adjacency list

---

## 🌍 Real-World Use Cases

| Domain | Application |
|---|---|
| **Operating Systems** | CPU process scheduling (Linux CFS, MLFQ) |
| **Build Systems** | `make`, Gradle — compile targets by dependency order |
| **Job Queues** | AWS SQS, Celery, Redis Queue — workers pick highest-priority jobs |
| **Hospital Triage** | Critical patients treated before low-urgency cases |
| **CI/CD Pipelines** | Stages execute after their upstream stages succeed |
| **Package Managers** | `npm install`, `pip` — install dependencies in topological order |

---

## 📤 GitHub Upload — Step-by-Step

### 1. Create repository on GitHub
Go to https://github.com/new → Name it `task-scheduler-system` → Create (do NOT add README).

### 2. Initialize local git
```bash
cd task-scheduler-system
git init
git add .
git commit -m "feat: initial Task Scheduler System implementation"
```

### 3. Push to GitHub
```bash
git remote add origin https://github.com/YOUR_USERNAME/task-scheduler-system.git
git branch -M main
git push -u origin main
```

### 4. Verify
Visit `https://github.com/YOUR_USERNAME/task-scheduler-system` — all files should appear.

---

## 👤 Author

Built as a Data Structures demonstration project targeting **Amazon SDE Internship** level.
Covers: Binary Heap, HashMap, Graph (BFS/DFS), Topological Sort, OOP design.
